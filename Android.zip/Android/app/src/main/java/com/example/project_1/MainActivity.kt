package com.example.project_1

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.project_1.ui.theme.Project_1Theme

class MainActivity : ComponentActivity() {
    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Project_1Theme {
                Scaffold {
                    HorizontalPages()
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HorizontalPages(){
    val pageState = rememberPagerState(pageCount = {3})

    HorizontalPager(state = pageState) { page ->
        when(page){
            0 -> PrimeraVentanaEjemplo()
            1 -> SegundaVentanaEjemplo()
            2 -> TerceraVentanaEjemplo()
            else -> Text(text = "No se encontró")
        }
    }

    Row(
        modifier = Modifier.fillMaxSize()
            .padding(vertical = 100.dp, horizontal = 30.dp)
        , horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.Bottom
    ) {
        repeat(3){ i ->
            Box(
                modifier = Modifier.size(10.dp)
                    .padding(horizontal = 2.dp)
                    .background(if (pageState.currentPage == i) Color.Black else Color.LightGray.copy(alpha = 0.5f),
                        shape = CircleShape)
            ) {

            }
        }
    }
}

@Composable
fun PrimeraVentanaEjemplo(){
    Box(
        modifier = Modifier.fillMaxSize().background(color = Color(0XFF00d7f9))
    ){
        Text(text = "Hola, desde ventana 1", modifier = Modifier.align(Alignment.Center))
    }
}

@Composable
fun SegundaVentanaEjemplo(){
    Box(
        modifier = Modifier.fillMaxSize().background(color = Color.Green)
    ){
        Text(text = "Hola, desde ventana 2", modifier = Modifier.align(Alignment.Center))
    }
}

@Composable
fun TerceraVentanaEjemplo(){
    Box(
        modifier = Modifier.fillMaxSize().background(color = Color.Red)
    ){
        Text(text = "Hola, desde ventana 3", modifier = Modifier.align(Alignment.Center))
    }
}